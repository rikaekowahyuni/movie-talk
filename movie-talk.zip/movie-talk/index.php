<?php
  function get_curl($url){
    $curl= curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result= curl_exec($curl);
    curl_close($curl);
    return json_decode($result, true);
  }
  // // Movie
  // $result = get_curl('https://api.themoviedb.org/3/trending/movie/day?api_key=5ec279387e9aa9488ef4d00b22acc451');
  // $titleMovie = $result ['results'][0]['title'];
  // $id = $result ['results'][0]['id'];
  // $overview = $result ['results'][0]['overview'];

  // // Youtube Video top
  // $q= str_replace(" ","%20", $titleMovie);
  // $urlVideo = 'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q='.$q.'&key=AIzaSyB-XokCHG_W19ZWxvhIZVGGE5FZnzya6IE';
  // $result = get_curl($urlVideo);
  // $thumbnail = $result ['items'][0]['snippet']['thumbnails']['high']['url'];
  // $videoTop = $result ['items'][0]['id']['videoId'];

  // // Movie Detail
  // $urlDetail = 'https://api.themoviedb.org/3/movie/'.$id.'?api_key=5ec279387e9aa9488ef4d00b22acc451'; 
  // $result= get_curl($urlDetail);
  // $imdbId = $result ['imdb_id'];
  // $durasi = $result ['runtime'];
  // $tagline = $result ['tagline'];
  // $rev = $result ['revenue'];
  // $budget = $result ['budget'];
  // $lang= [];
  // foreach($result ['spoken_languages'] as $language){
  //   $lang[] = $language['name'];
  // };

  // // imdb detail 
  // $urlImdb = 'http://www.omdbapi.com?apikey=2941b0f7&i='.$imdbId.'';
  // $result = get_curl($urlImdb);
  // $year = $result ['Year'];
  // $rating = $result ['imdbRating'];
  // $awards = $result ['Awards'];
  // $genre = $result ['Genre'];
  // $actors = $result ['Actors'];

  // // Coming soon
  // $urlSoon = 'https://api.themoviedb.org/3/movie/upcoming?api_key=5ec279387e9aa9488ef4d00b22acc451&language=en-US&page=1';
  // $result = get_curl($urlSoon);
  // $judul1 = $result ['results'][2]['title'];
  // $judul2 = $result ['results'][4]['title'];
  // $judul3 = $result ['results'][13]['title'];
  // $judul4 = $result ['results'][16]['title'];
  // $id1 = $result ['results'][2]['id'];
  // $id2 = $result ['results'][4]['id'];
  // $id3 = $result ['results'][13]['id'];
  // $id4 = $result ['results'][16]['id'];
  // $overview1 = $result ['results'][2]['overview'];
  // $overview2 = $result ['results'][4]['overview'];
  // $overview3 = $result ['results'][13]['overview'];
  // $overview4 = $result ['results'][16]['overview'];


  // // Movie detail 2
  // $urlDetail1 = 'https://api.themoviedb.org/3/movie/'.$id1.'?api_key=5ec279387e9aa9488ef4d00b22acc451'; 
  // $result= get_curl($urlDetail1);
  // $imdbId2 = $result ['imdb_id'];
  // $tagline2 = $result ['tagline'];
  // $rev2 = $result ['revenue'];
  // $budget2 = $result ['budget'];
  // $lang2= [];
  // foreach($result ['spoken_languages'] as $language2){
  //   $lang2[] = $language2['name'];
  // };

  // // imdb detail 2
  // $urlImdb2 = 'http://www.omdbapi.com?apikey=2941b0f7&i='.$imdbId2.'';
  // $result = get_curl($urlImdb2);
  // $genre2 = $result ['Genre'];
  // $actors2 = $result ['Actors'];
  // $poster1 = $result ['Poster'];

  // // Movie detail 6
  // $urlDetail2 = 'https://api.themoviedb.org/3/movie/'.$id2.'?api_key=5ec279387e9aa9488ef4d00b22acc451'; 
  // $result= get_curl($urlDetail2);
  // $imdbId6 = $result ['imdb_id'];
  // $tagline6 = $result ['tagline'];
  // $rev6 = $result ['revenue'];
  // $budget6 = $result ['budget'];
  // $lang6= [];
  // foreach($result ['spoken_languages'] as $language6){
  //   $lang6[] = $language6['name'];
  // };


  // // imdb detail 6
  // $urlImdb2 = 'http://www.omdbapi.com?apikey=2941b0f7&i='.$imdbId6.'';
  // $result = get_curl($urlImdb2);
  // $genre6 = $result ['Genre'];
  // $actors6 = $result ['Actors'];
  // $poster2 = $result ['Poster'];

  // // Movie detail 14
  // $urlDetail3 = 'https://api.themoviedb.org/3/movie/'.$id3.'?api_key=5ec279387e9aa9488ef4d00b22acc451'; 
  // $result= get_curl($urlDetail3);
  // $imdbId14 = $result ['imdb_id'];
  // $tagline14 = $result ['tagline'];
  // $rev14 = $result ['revenue'];
  // $budget14 = $result ['budget'];
  // $lang14= [];
  // foreach($result ['spoken_languages'] as $language14){
  //   $lang14[] = $language14['name'];
  // };


  // // imdb detail 14
  // $urlImdb3 = 'http://www.omdbapi.com?apikey=2941b0f7&i='.$imdbId14.'';
  // $result = get_curl($urlImdb3);
  // $genre14 = $result ['Genre'];
  // $actors14 = $result ['Actors'];
  // $poster14 = $result ['Poster'];

  // // Movie detail 16
  // $urlDetail4 = 'https://api.themoviedb.org/3/movie/'.$id4.'?api_key=5ec279387e9aa9488ef4d00b22acc451'; 
  // $result= get_curl($urlDetail4);
  // $imdbId16 = $result ['imdb_id'];
  // $tagline16 = $result ['tagline'];
  // $rev16 = $result ['revenue'];
  // $budget16 = $result ['budget'];
  // $lang16= [];
  // foreach($result ['spoken_languages'] as $language16){
  //   $lang16[] = $language16['name'];
  // };

  // // imdb detail 16
  // $urlImdb4 = 'http://www.omdbapi.com?apikey=2941b0f7&i='.$imdbId16.'';
  // $result = get_curl($urlImdb4);
  // $genre16 = $result ['Genre'];
  // $actors16 = $result ['Actors'];
  // $poster4 = $result ['Poster'];



  // // Now Playing
  // $urlNow = 'https://api.themoviedb.org/3/movie/now_playing?api_key=5ec279387e9aa9488ef4d00b22acc451';
  // $result = get_curl($urlNow);
  // $judulN = $result ['results'][1]['title'];
  // $judulN1 = $result ['results'][2]['title'];
  // $judulN2 = $result ['results'][8]['title'];
  // $idN1 = $result ['results'][1]['id'];
  // $idN2 = $result ['results'][2]['id'];
  // $idN3 = $result ['results'][8]['id'];
  // $overviewN1 = $result ['results'][1]['overview'];
  // $overviewN2 = $result ['results'][2]['overview'];
  // $overviewN3 = $result ['results'][8]['overview'];
  // $posterN1 = $result ['results'][1]['poster_path'];
  // $posterN2 = $result ['results'][2]['poster_path'];
  // $posterN3 = $result ['results'][8]['poster_path'];

  // // Youtube Video N1
  // $n= str_replace(" ","%20", $judulN);
  // $urlVideon = 'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q='.$n.'&key=AIzaSyB-XokCHG_W19ZWxvhIZVGGE5FZnzya6IE';
  // $result = get_curl($urlVideon);
  // $videon = $result ['items'][0]['id']['videoId'];

  // // Youtube Video N2
  // $n1= str_replace(" ","%20", $judulN1);
  // $urlVideon1 = 'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q='.$n1.'%20trailer&key=AIzaSyB-XokCHG_W19ZWxvhIZVGGE5FZnzya6IE';
  // $result = get_curl($urlVideon1);
  // $videon1 = $result ['items'][0]['id']['videoId'];

  // // Youtube Video N3
  // $n2= str_replace(" ","%20", $judulN2);
  // $urlVideon2 = 'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q='.$n2.'&key=AIzaSyB-XokCHG_W19ZWxvhIZVGGE5FZnzya6IE';
  // $result = get_curl($urlVideon2);
  // $videon2 = $result ['items'][0]['id']['videoId'];

  // //top actor
  // $urlAct = 'https://api.themoviedb.org/3/person/popular?api_key=5ec279387e9aa9488ef4d00b22acc451&page=1';
  // $result = get_curl($urlAct);
  // $data = [];
  // $foto= [];
  // $nama=[];
  // $sub=[];
  // $over=[];
  // foreach($result ['results'] as $p){
  //   $data[] = [
  //   $foto[] = $p['profile_path'],
  //   $nama[] = $p ['name'],
  //   $sub[] = $p['known_for_department'],
  //   $over[] = $p['known_for'][1]['overview']
  //   ];
  // }

  // Youtube recomendasi 

  $urlVideorec = 'https://www.googleapis.com/youtube/v3/search?key=AIzaSyCKFsGvsnRoSV0qznSUICJsGyOmT2j0yI8&channelId=UCi8e0iOVk1fEOogdfu4YgfA&maxResults=3&order=date&part=snippet';
  $result = get_curl($urlVideorec);
  $videorec = [];
  foreach($result['items']as $r){
    $videorec[] = $r ['id']['videoId'];
  }

  // Youtube recomendasi 1

  $urlVideorec1 = 'https://www.googleapis.com/youtube/v3/search?key=AIzaSyCKFsGvsnRoSV0qznSUICJsGyOmT2j0yI8&channelId=UCpJN7kiUkDrH11p0GQhLyFw&maxResults=3&order=date&part=snippet';
  $result = get_curl($urlVideorec1);
  $videorec1 = [];
  foreach($result['items']as $r){
    $videorec1[] = $r ['id']['videoId'];
  }
 

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Movie Talk</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/logo.png" rel="logo-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container-fluid d-flex align-items-center justify-content-between">
      <a href="index.php" class="logo"><img src="assets/img/logo.png" alt="Movie Talk" class="img-fluid"></a>

      <nav class="nav-menu d-none d-lg-block">
        <ul id="menu-kanan">
          <li class="active"><a href="#hero">Home</a></li>
          <li><a href="#video">Trending</a></li>
          <li><a href="#about-boxes">Now Playing</a></li>
          <li><a href="#features">Coming Soon</a></li>
          <li><a href="#services">What They Think</a></li>
          <li><a href="#testimonials">Top Actor</a></li>
          <li><a href="#team">Team</a></li>
          <li><a href="#contact">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container" data-aos="fade-up" data-aos-delay="150">
      <h1>Watch. Love. Talk.</h1>
      <h2>Watch Movies or Tv Shows and get to know more about your movie!</h2>
      <div class="d-flex">
        <a href="search.php" class="btn-get-started scrollto">Search Movie</a>
      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= video Section ======= -->
    <section id="video" class="about">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Trending</h2>
        </div>
        <div class="row justify-content-end">
          <div class="col-lg-11">
            <div class="row justify-content-end">

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="icofont-simple-smile"></i>
                  <span data-toggle="counter-up"><?= $rating; ?></span>
                  <p>Rate</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="icofont-calendar"></i>
                  <span data-toggle="counter-up"><?= $year;?></span>
                  <p>Release</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="icofont-clock-time"></i>
                  <span data-toggle="counter-up"><?=$durasi;?></span>
                  <p>minutes</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="icofont-award"></i>
                  <span data-toggle="counter-up"><?= substr($awards,-14,1);?></span>
                  <p>Awards</p>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class="row">

          <div class="col-lg-5 video-box align-self-baseline" data-aos="zoom-in" data-aos-delay="100">
            <img src="<?=$thumbnail;?>" class="img-fluid" alt="">
            <a href="https://www.youtube.com/watch?v=<?=$videoTop;?>" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
          </div>

          <div class="col-lg-7 pt-3 pt-lg-0 content">
            <h3><?=  $titleMovie; ?></h3>
            <p class="font-italic"> <?=$overview;?> </p>
            <ul>
              <li><i class="bx bx-check-double"></i> Genre : <?=$genre;?></li>
              <li><i class="bx bx-check-double"></i> Actors : <?=$actors;?></li>
              <li><i class="bx bx-check-double"></i> Languange : <?php foreach ($lang as $language):
                echo $language;
                echo ", "; 
              endforeach;?></li>
              <li><i class="bx bx-check-double"></i> Budget : <?=$budget;?></li>
              <li><i class="bx bx-check-double"></i> Revenue : <?=$rev;?></li>
            </ul>
            <p>
              <?=$tagline;?>
            </p>
          </div>

        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= About Boxes Section ======= -->
    <section id="about-boxes" class="about-boxes">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Now Playing</h2>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="card">
              <img src="http://image.tmdb.org/t/p/w200<?=$posterN1;?>" class="card-img-top" alt="...">
              <div class="card-icon">
                <i class="icofont-youtube-play"></i>
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="https://www.youtube.com/watch?v=<?=$videon;?>"><?=$judulN;?></a></h5>
                <p class="card-text"><?=$overviewN1;?> </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="card">
              <img src="http://image.tmdb.org/t/p/w500<?=$posterN2;?>" class="card-img-top" alt="...">
              <div class="card-icon">
                <i class="icofont-youtube-play"></i>
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="https://www.youtube.com/watch?v=<?=$videon1;?>"><?=$judulN1;?></a></h5>
                <p class="card-text"><?=$overviewN2;?> </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
            <div class="card">
              <img src="http://image.tmdb.org/t/p/w200<?=$posterN3;?>" class="card-img-top" alt="...">
              <div class="card-icon">
                <i class="icofont-youtube-play"></i>
              </div>
              <div class="card-body">
                <h5 class="card-title"><a href="https://www.youtube.com/watch?v=<?=$videon2;?>" ><?=$judulN2;?></a></h5>
                <p class="card-text"><?=$overviewN3;?></p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Boxes Section -->


    <!-- ======= Features Section ======= -->
    <section id="features" class="features">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Coming Soon</h2>
          <p>What's Next?</p>
        </div>

        <ul class="nav nav-tabs row d-flex">
          <li class="nav-item col-3">
            <a class="nav-link active show" data-toggle="tab" href="#tab-1">
              <h4 class="d-none d-lg-block"><?=$judul1;?></h4>
            </a>
          </li>
          <li class="nav-item col-3">
            <a class="nav-link" data-toggle="tab" href="#tab-2">
              <h4 class="d-none d-lg-block"><?=$judul2;?></h4>
            </a>
          </li>
          <li class="nav-item col-3">
            <a class="nav-link" data-toggle="tab" href="#tab-3">
              <h4 class="d-none d-lg-block"><?=$judul3;?></h4>
            </a>
          </li>
          <li class="nav-item col-3">
            <a class="nav-link" data-toggle="tab" href="#tab-4">
              <h4 class="d-none d-lg-block"><?=$judul4;?></h4>
            </a>
          </li>
        </ul>

        <div class="tab-content">
          <div class="tab-pane active show" id="tab-1">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3><?= $judul1; ?></h3>
                <p class="font-italic"><?=$overview1?></p>
                <ul>
                  <li><i class="bx bx-check-double"></i> Genre : <?=$genre2;?></li>
                  <li><i class="bx bx-check-double"></i> Actors : <?=$actors2;?></li>
                  <li><i class="bx bx-check-double"></i> Languange : <?php foreach ($lang2 as $language2):
                    echo $language2;
                    echo ", "; 
                  endforeach;?></li>
                  <li><i class="bx bx-check-double"></i> Budget : <?=$budget2;?></li>
                  <li><i class="bx bx-check-double"></i> Revenue : <?=$rev2;?></li>
                </ul>
                <p>
                  <?=$tagline2;?>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="<?=$poster1;?>" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-2">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3><?= $judul2; ?></h3>
                <p><?=$overview2?></p>
                <p class="font-italic">
                  "<?=$tagline6;?>"
                </p>
                <ul>
                  <li><i class="bx bx-check-double"></i> Genre : <?=$genre6;?></li>
                  <li><i class="bx bx-check-double"></i> Actors : <?=$actors6;?></li>
                  <li><i class="bx bx-check-double"></i> Languange : <?php foreach ($lang6 as $language6):
                    echo $language6;
                    echo ", "; 
                  endforeach;?></li>
                  <li><i class="bx bx-check-double"></i> Budget : <?=$budget6;?></li>
                  <li><i class="bx bx-check-double"></i> Revenue : <?=$rev6;?></li>
                </ul>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="<?=$poster2;?>" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-3">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3><?= $judul3; ?></h3>
                <p><?=$overview3?></p>
                <ul>
                  <li><i class="bx bx-check-double"></i> Genre : <?=$genre14;?></li>
                  <li><i class="bx bx-check-double"></i> Actors : <?=$actors14;?></li>
                  <li><i class="bx bx-check-double"></i> Languange : <?php foreach ($lang14 as $language14):
                    echo $language14;
                    echo ", "; 
                  endforeach;?></li>
                  <li><i class="bx bx-check-double"></i> Budget : <?=$budget14;?></li>
                  <li><i class="bx bx-check-double"></i> Revenue : <?=$rev14;?></li>
                </ul>
                <p class="font-italic">
                  <?=$tagline14;?>
                </p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="<?= $poster14;?>" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-4">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3><?= $judul4; ?></h3>
                <p><?=$overview4?></p>
                <p class="font-italic">
                  "<?=$tagline16;?>"
                </p>
                <ul>
                  <li><i class="bx bx-check-double"></i> Genre : <?=$genre16;?></li>
                  <li><i class="bx bx-check-double"></i> Actors : <?=$actors16;?></li>
                  <li><i class="bx bx-check-double"></i> Languange : <?php foreach ($lang16 as $language16):
                    echo $language16;
                    echo ", "; 
                  endforeach;?></li>
                  <li><i class="bx bx-check-double"></i> Budget : <?=$budget16;?></li>
                  <li><i class="bx bx-check-double"></i> Revenue : <?=$rev16;?></li>
                </ul>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="<?=$poster4;?>" alt="" class="img-fluid">
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Features Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>More Video on Youtube</h2>
          <p>What They Think?</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="200">
          <?php foreach ($videorec as $rec): ?>
            <div class="col-md-4 mt-4 mt-md-0">
              <div class="icon-box">
                <iframe width="100%" height="100%" src="https://www.youtube.com/embed/<?=$rec;?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
            </div>
          <?php endforeach;?>
          <?php foreach ($videorec1 as $rec1): ?>
            <div class="col-md-4 mt-4 mt-md-0">
              <div class="icon-box">
              <iframe width="100%" height="100%" src="https://www.youtube.com/embed/<?=$rec1;?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> 
              </div> 
            </div>
          <?php endforeach;?>
        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="zoom-in">

        <div class="section-title">
          <h2>Top Actors</h2>
        </div>

        <div class="owl-carousel testimonials-carousel">

          <?php foreach ($data as list($foto, $nama, $sub, $over)): ?>
          <div class="testimonial-item">
            <img src="http://image.tmdb.org/t/p/w200<?=$foto;?>" class="testimonial-img" alt="">
            <h3><?=$nama?></h3>
            <h4><?=$sub?></h4>
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              <?=$over?>
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
          </div>
          <?php endforeach;?>
        

        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Team</h2>
          <p>Check our Team</p>
        </div> 
         
        <div class="row">

          <div class="col-lg-2 col-md-6"></div>          

          <div class="col-lg-4 col-md-6">
            <div class="member" data-aos="fade-up" data-aos-delay="100">
              <div class="pic"><img src="assets/img/team/alfia.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Alfia Rahmania Putri</h4>
                <span>17082010004</span>
                <div class="social">
                  <a href="https://www.youtube.com/channel/UCsVRRrrSZGaximYHlCxa2Jw"><i class="icofont-youtube-play"></i></a>
                  <a href="https://www.facebook.com/alfia.spendamoxer"><i class="icofont-facebook"></i></a>
                  <a href="https://instagram.com/alfiarahmaniap?igshid=kpa2x2g6loqq"><i class="icofont-instagram"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="member">
              <div class="pic"><img src="assets/img/team/rika.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Rika Eko Wahyuni</h4>
                <span>17082010014</span>
                <div class="social">
                  <a href="https://twitter.com/rk_3001?s=09"><i class="icofont-twitter"></i></a>
                  <a href="https://www.facebook.com/YuniRika"><i class="icofont-facebook"></i></a>
                  <a href="https://instagram.com/rikaekowahyuni?igshid=12znbe3kmlwvu"><i class="icofont-instagram"></i></a>
                  <a href="https://www.linkedin.com/in/rika-eko-wahyuni-4356751a5"><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-2 col-md-6"></div>

        </div>

      </div>
    </section><!-- End Team Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">
        <div class=" section-title">
          <h2>Contact</h2>
        </div>

        <div>
          <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d63320.021167217434!2d112.7284736!3d-7.2974336!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7fbe20c11b5b9%3A0x56849f4959688b0b!2sFakultas%20Ilmu%20Komputer%20-%20UPN%20Veteran%20Jatim!5e0!3m2!1sid!2sid!4v1590986840389!5m2!1sid!2sid" width="100%" height="350px" frameborder="0" style="border:0;" allowfullscreen></iframe>
        </div>
          <div class="row">
            <div class="col-md-12">
              <div class="info-box">
                <i class="bx bxs-landmark"></i>
                <h3>Universitas Pembangunan Nasional "Veteran" Jawa Timur</h3>
              </div>
            </div>
            <div class="col-md-6">
              <div class="info-box mt-4">
                <i class="bx bx-code-block"></i>
                <h3>Fakultas Ilmu Komputer</h3>
              </div>
            </div>
            <div class="col-md-6">
              <div class="info-box mt-4">
                <i class="bx bxs-book-open"></i>
                <h3>Program Studi Sistem Informasi</h3>
              </div>
            </div>
          </div>
      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>AlfiaRika</span></strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>