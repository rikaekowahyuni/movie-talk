function SearchMovie(){
    $('#movie-list').html('');
    $.ajax({
        url:'http://www.omdbapi.com',
        type: 'GET',
        dataType:'JSON',
        data:{
            'apikey' : '2941b0f7',
            's' : $('#search-input').val()
        },
        success: function(result){
            if(result.Response == "True"){

                let movies = result.Search;

                $.each(movies, function(i, data){
                    $('#movie-list').append(`
                    <div class="col-lg-3 portfolio-item filter-app">
                        <img src="`+ data.Poster +`" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4>`+ data.Title +`</h4>
                            <p>`+ data.Year +`</p>
                            <a href="movie-details.php?&id=`+data.imdbID+`" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
                        </div>
                    </div>
                    `);
                });

            }else{
                $('#movie-list').html(`
                <div class="col-lg-12">
                    <center
                        <strong><h4 class="text-center">` + result.Error + `</h4></strong>
                    </center>
                </div>
                `)
            }
        }
    });
}
$('#search-button').on('click',function(){
    SearchMovie();
});

$('#search-input').on('keyup', function(e){
    if(e.which === 13){
        SearchMovie();
    }
}); 

$('#movie-list').on('click', '.details-link', function(){
    $.ajax({
        url:'http://www.omdbapi.com',
        type: 'GET',
        dataType:'JSON',
        data:{
            'apikey' : '2941b0f7',
            'i' : $(this).data('id')
        },
        success: function(movie){
            if(movie.Response === "True"){
                $('.portfolio-info').html(`
                    <h3>`+ movie.Title +`</h3>
                    <ul>
                    <li><strong>Rating</strong>: `+ movie.imdbRating +`</li>
                    <li><strong>Released</strong>: `+ movie.Released +`</li>
                    <li><strong>Genre</strong>: `+ movie.Genre +`</li>
                    <li><strong>Production</strong>: `+ movie.Production +`</li>
                    </ul>
                `);
                $('.portfolio-description').html(`
                    <h2>This movie have `+ movie.Awards +`</h2>
                    <p>
                    `+ movie.Plot +`
                    </p>
                `);

            }
        }
    });
});
