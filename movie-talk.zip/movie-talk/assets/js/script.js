$(document).ready(function(){
    $('#portfolio').hide();
});

$('#search-button').on('click',function(){
    $('#portfolio').show();
    $('#hero').hide();
});